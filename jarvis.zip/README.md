# JARVIS - Advanced Personal AI Assistant
**Developed by Subodh Jadhav**

JARVIS (Just A Rather Very Intelligent System) is a high-performance personal assistant designed to bridge the gap between human intelligence and digital execution. This project implements a futuristic, responsive interface and a powerful core engine capable of cross-platform operation.

## 🚀 Key Features
- **Brain-Like Intelligence**: Advanced command processing that understands context.
- **Background Search**: Real-time information retrieval without browser redirection.
- **Device Control**: (Laptop) Open/Close applications, system stats monitoring.
- **Communication**: Simulation of incoming and outgoing calls with voice interaction.
- **Academic Prowess**: Solves complex mathematics and general knowledge questions instantly.
- **Android Integration**: Designed as a PWA (Progressive Web App) to work in the background and on modern mobile browsers.
- **Wake Word Recognition**: Responds to the name 'Jarvis'.
- **Futuristic UI**: High-fidelity glassmorphism, glowing visualizers, and scanning animations.

## 🛠️ Components
1. **Frontend (Web)**: `index.html`, `style.css`, `app.js` - The visual Hub of JARVIS.
2. **Backend Engine (Python)**: `system_engine.py` - Handles system-level tasks like closing apps and local file access.
3. **PWA Support**: `manifest.json` - Allows installation on Android for background persistence.

## 📱 Mobile Operation
To use JARVIS on Android with "Screen Off" capabilities:
- JARVIS is built as a PWA. Add it to your Home Screen from your mobile browser.
- For true background wake-word detection when the screen is off, it is recommended to wrap the `system_engine.py` logic in a native Kivy/Flutter service or use the provided Web Speech API in a background-persistent browser tab.

## 💻 Technical Setup
### For the Web Interface:
Simply open `index.html` in a modern browser (Chrome/Edge/Safari). Click the central Orb to initialize the voice interface.

### For the System Engine (Laptop):
1. Install dependencies:
   ```bash
   pip install pyttsx3 speechrecognition psutil
   ```
2. Run the engine:
   ```bash
   python system_engine.py
   ```

---
*Created with passion by Subodh Jadhav.*
