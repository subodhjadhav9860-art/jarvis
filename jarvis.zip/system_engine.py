import os
import sys
import psutil
import pyttsx3
import speech_recognition as sr
import webbrowser
import math

class JarvisEngine:
    def __init__(self):
        self.engine = pyttsx3.init()
        self.voices = self.engine.getProperty('voices')
        self.engine.setProperty('voice', self.voices[0].id) # Usually male for Jarvis
        self.engine.setProperty('rate', 170)

    def speak(self, text):
        print(f"JARVIS: {text}")
        self.engine.say(text)
        self.engine.runAndWait()

    def listen(self):
        r = sr.Recognizer()
        with sr.Microphone() as source:
            print("Listening...")
            r.pause_threshold = 1
            audio = r.listen(source)
        try:
            print("Recognizing...")
            query = r.recognize_google(audio, language='en-in')
            print(f"User said: {query}\n")
        except Exception as e:
            print("Say that again please...")
            return "None"
        return query.lower()

    def solve_math(self, expression):
        try:
            # Dangerous to use eval directly in prod, but for personal assistant:
            result = eval(expression.replace('x', '*'))
            self.speak(f"The result is {result}")
        except:
            self.speak("I couldn't calculate that.")

    def open_application(self, app_name):
        app_name = app_name.lower().replace("open ", "").strip()
        self.speak(f"Accessing system core to launch {app_name}")
        
        # Try using AppOpener for robust system app launching
        try:
            from AppOpener import open as open_app
            open_app(app_name, match_closest=True)
            return
        except ImportError:
            # Fallback to manual mapping if AppOpener isn't installed
            apps = {
                "notepad": "notepad.exe",
                "calculator": "calc.exe",
                "settings": "start ms-settings:",
                "paint": "mspaint.exe",
                "chrome": "start chrome",
                "edge": "start msedge",
                "task manager": "taskmgr.exe",
                "command prompt": "start cmd",
                "powershell": "start powershell"
            }

            if app_name in apps:
                os.system(apps[app_name])
            else:
                os.system(f"start {app_name}")

    def close_application(self, process_name):
        process_name = process_name.lower().replace("close ", "").replace("terminate ", "").strip()
        self.speak(f"Terminating {process_name} process.")
        
        # Try using AppOpener for robust system app closing
        try:
            from AppOpener import close as close_app
            close_app(process_name, match_closest=True)
            return
        except ImportError:
            proc_map = {
                "notepad": "notepad.exe",
                "calculator": "CalculatorApp.exe",
                "chrome": "chrome.exe",
                "edge": "msedge.exe",
                "paint": "mspaint.exe",
                "settings": "SystemSettings.exe"
            }
            
            target = proc_map.get(process_name, process_name)
            
            found = False
            for proc in psutil.process_iter(['name']):
                try:
                    if target in proc.info['name'].lower():
                        proc.kill()
                        found = True
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            
            if found:
                self.speak(f"Successfully closed {process_name}.")
            else:
                self.speak(f"I couldn't find an active process for {process_name}.")

    def list_photos(self):
        self.speak("Accessing local photo storage.")
        photo_dir = os.path.join(os.path.expanduser("~"), "Pictures")
        try:
            photos = os.listdir(photo_dir)
            self.speak(f"I found {len(photos)} items in your gallery.")
            return photos
        except:
            self.speak("Directory access denied.")

    def get_call_logs(self):
        # Simulated log retrieval - on Laptop this might be from a sync app
        self.speak("Retrieving synchronized call logs.")
        # Mock data
        logs = ["Mom - 2:30 PM", "Subodh Jadhav - 1:15 PM", "Office - 10:00 AM"]
        for log in logs:
            print(f"LOG: {log}")
        self.speak(f"Last call was from {logs[0].split(' - ')[0]}")

    def change_volume(self, direction):
        import ctypes
        WM_APPCOMMAND = 0x319
        APPCOMMAND_VOLUME_UP = 0x0a
        APPCOMMAND_VOLUME_DOWN = 0x09
        APPCOMMAND_VOLUME_MUTE = 0x08
        
        hwnd_active = ctypes.windll.user32.GetForegroundWindow()
        if direction == "up":
            self.speak("Increasing volume.")
            for _ in range(5): ctypes.windll.user32.SendMessageW(hwnd_active, WM_APPCOMMAND, hwnd_active, APPCOMMAND_VOLUME_UP << 16)
        elif direction == "down":
            self.speak("Decreasing volume.")
            for _ in range(5): ctypes.windll.user32.SendMessageW(hwnd_active, WM_APPCOMMAND, hwnd_active, APPCOMMAND_VOLUME_DOWN << 16)
        elif direction == "mute":
            self.speak("Muting audio.")
            ctypes.windll.user32.SendMessageW(hwnd_active, WM_APPCOMMAND, hwnd_active, APPCOMMAND_VOLUME_MUTE << 16)

    def lock_system(self):
        import ctypes
        self.speak("Securing workstation. Access restricted.")
        ctypes.windll.user32.LockWorkStation()

    def get_battery_status(self):
        battery = psutil.sensors_battery()
        percent = battery.percent
        self.speak(f"System battery is at {percent} percent.")
        if battery.power_plugged:
            self.speak("Power source is connected. Charging.")
        else:
            self.speak("We are currently running on battery power.")

    def search_intelligence(self, query):
        self.speak(f"Searching my background database for {query}")
        # In a real scenario, connect to an LLM or Search API here.
        # Simulation:
        self.speak(f"Found it. {query} is a fascinating topic developed by Subodh Jadhav's advanced modules.")

if __name__ == "__main__":
    jarvis = JarvisEngine()
    jarvis.speak("System initialized. I am JARVIS, your personal assistant, developed by Subodh Jadhav.")
    
    while True:
        query = jarvis.listen().lower()
        
        if "jarvis" in query:
            query = query.replace("jarvis", "").strip()
            
            if not query or "hello" in query:
                jarvis.speak("Online and ready, sir.")
            
            elif "volume up" in query:
                jarvis.change_volume("up")
            elif "volume down" in query:
                jarvis.change_volume("down")
            elif "mute" in query:
                jarvis.change_volume("mute")
            elif "battery" in query:
                jarvis.get_battery_status()
            elif "lock" in query:
                jarvis.lock_system()
            elif "open" in query:
                app = query.replace("open", "").strip()
                jarvis.open_application(app)
            
            elif "close" in query or "terminate" in query:
                app = query.replace("close", "").replace("terminate", "").strip()
                jarvis.close_application(app)
                
            elif "calculate" in query or "math" in query:
                jarvis.solve_math(query)
                
            elif "photo" in query or "gallery" in query:
                jarvis.list_photos()
            
            elif "call log" in query:
                jarvis.get_call_logs()
                
            elif "who" in query or "tell me" in query:
                jarvis.search_intelligence(query)
                
            elif "exit" in query or "stop" in query:
                jarvis.speak("Shutting down core systems. Goodbye.")
                break
            
            else:
                jarvis.speak(f"I've noted your request regarding {query}. My intelligence modules are processing.")
