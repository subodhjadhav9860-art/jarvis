const transcriptEl = document.getElementById('transcript');
const responseEl = document.getElementById('response');
const timeEl = document.getElementById('time');
const dateEl = document.getElementById('date');
const coreOrb = document.getElementById('voice-trigger');

// Register Service Worker for APK support
if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('./service-worker.js')
        .then(() => console.log("JARVIS: Offline Core Activated."))
        .catch(err => console.error("JARVIS: Link Failed.", err));
}

// System Stats Simulation
setInterval(() => {
    document.getElementById('cpu-bar').style.width = Math.floor(Math.random() * 20 + 30) + '%';
    document.getElementById('mem-bar').style.width = Math.floor(Math.random() * 10 + 20) + '%';
}, 3000);

// Clock
function updateClock() {
    const now = new Date();
    timeEl.innerText = now.toLocaleTimeString([], { hour12: false });
    dateEl.innerText = now.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }).toUpperCase();
}
setInterval(updateClock, 1000);
updateClock();

// Speech Synthesis
function speak(text) {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.1;
    utterance.pitch = 0.9;
    window.speechSynthesis.speak(utterance);
    responseEl.innerText = text;
}

function getGreeting() {
    const hours = new Date().getHours();
    if (hours < 12) return "Good Morning, Subodh Jadhav.";
    if (hours < 17) return "Good Afternoon, Subodh Jadhav.";
    return "Good Evening, Subodh Jadhav.";
}

// Speech Recognition
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
if (SpeechRecognition) {
    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = false;

    recognition.onstart = () => {
        console.log('Voice recognition activated.');
    };

    recognition.onresult = (event) => {
        const transcript = event.results[event.results.length - 1][0].transcript.toLowerCase().trim();
        transcriptEl.innerText = `User: "${transcript}"`;
        handleCommand(transcript);
    };

    recognition.onerror = (event) => {
        console.error('Recognition error:', event.error);
    };

    coreOrb.onclick = () => {
        try {
            recognition.start();
            speak("System initialized. Listening for commands.");
        } catch (e) {
            console.log("Already listening");
        }
    };

    // Auto-start conceptual (User must interact first usually)
} else {
    transcriptEl.innerText = "Speech Recognition not supported in this browser.";
}

// Command Handler
let openedTabs = {};

function handleCommand(command) {
    if (command.includes('jarvis')) {
        const query = command.replace('jarvis', '').trim();

        if (query === '' || query === 'hello' || query === 'wake up') {
            speak(`${getGreeting()} I am online and ready.`);
            return;
        }

        if (query.includes('self destruct')) {
            speak("Initiating self-destruction sequence. 5. 4. 3. 2. 1. Just kidding, Subodh. I am not going anywhere.");
            document.body.style.backgroundColor = '#ff000033';
            setTimeout(() => document.body.style.backgroundColor = '#050a14', 2000);
        } else if (query.includes('volume') || query.includes('battery') || query.includes('lock')) {
            speak("Direct hardware command detected. Please ensure my Python System Engine is active to execute this request.");
        } else if (query.includes('close')) {
            closeApp(query);
        } else if (query.includes('calculate') || query.includes('math') || query.match(/[0-9]/)) {
            solveMath(query);
        } else if (query.includes('open')) {
            openApp(query);
        } else if (query.includes('who') || query.includes('what') || query.includes('where') || query.includes('tell me about')) {
            solveGK(query);
        } else if (query.includes('call')) {
            simulateCall();
        } else {
            speak("Scanning cosmic databases for information...");
            responseEl.innerHTML = '<i class="fa-solid fa-sync fa-spin"></i> INTERROGATING CORE...';
            // Simulate background search result
            setTimeout(() => {
                const info = "Intelligence scan complete. " + query + " is recognized as a key priority. Our engine suggests substantial value in this inquiry.";
                speak(info);
            }, 3000);
        }
    }
}

function solveMath(query) {
    try {
        // Simple regex to extract math
        const expression = query.replace(/[^0-9+\-*/().]/g, '');
        if (expression) {
            const result = eval(expression);
            speak(`The result of ${expression} is ${result}`);
        } else {
            speak("I couldn't identify the numbers, please repeat.");
        }
    } catch (e) {
        speak("Calculation error. Please provide a clear mathematical expression.");
    }
}

function openApp(query) {
    const app = query.replace('open', '').toLowerCase().trim();
    speak(`Initiating protocol to open ${app}.`);

    let url = "";
    if (app.includes('youtube')) url = 'https://www.youtube.com';
    else if (app.includes('google')) url = 'https://www.google.com';
    else if (app.includes('facebook')) url = 'https://www.facebook.com';
    else if (app.includes('instagram')) url = 'https://www.instagram.com';
    else if (app.includes('twitter') || app.includes('x')) url = 'https://www.x.com';
    else if (app.includes('whatsapp')) url = 'https://web.whatsapp.com';
    else if (app.includes('github')) url = 'https://www.github.com';
    else {
        // Recognition of System Apps
        const systemApps = ['notepad', 'calculator', 'settings', 'paint', 'task manager'];
        if (systemApps.some(s => app.includes(s))) {
            speak(`Alert: I cannot launch system applications like ${app} directly from the browser for security. Please run my Python System Engine for full laptop control.`);
            return;
        }
        url = `https://www.google.com/search?q=${app}`;
        speak(`I couldn't find a specific module for ${app}, searching on the web instead.`);
    }

    if (url) {
        const win = window.open(url, '_blank');
        if (win) {
            openedTabs[app] = win;
        } else {
            speak("System alert: The browser blocked the popup. Please allow popups for JARVIS.");
        }
    }
}

function closeApp(query) {
    const app = query.replace('close', '').toLowerCase().trim();
    if (openedTabs[app]) {
        openedTabs[app].close();
        delete openedTabs[app];
        speak(`Closing ${app} as requested.`);
    } else {
        const systemApps = ['notepad', 'calculator', 'settings', 'paint', 'task manager'];
        if (systemApps.some(s => app.includes(s))) {
            speak(`System application ${app} must be closed via the Python System Engine.`);
        } else {
            speak(`I don't have an active link to ${app}. it might have been closed manually.`);
        }
    }
}

function solveGK(query) {
    // Simulated offline knowledge or background fetch
    if (query.includes('subodh jadhav')) {
        speak("Subodh Jadhav is the visionary developer who created my core intelligence.");
    } else if (query.includes('sky color')) {
        speak("The sky appears blue due to Rayleigh scattering.");
    } else {
        speak(`Searching my database for ${query}. According to my records, it is a significant topic in general knowledge.`);
    }
}

function simulateCall() {
    const overlay = document.getElementById('call-overlay');
    overlay.classList.remove('hidden');
    speak("Incoming call detected.");

    document.getElementById('btn-accept').onclick = () => {
        overlay.classList.add('hidden');
        speak("Call connected via satellite link.");
    };

    document.getElementById('btn-decline').onclick = () => {
        overlay.classList.add('hidden');
        speak("Call rejected.");
    };
}

// Module Viewers
function openModule(name) {
    speak(`Accessing ${name} management system.`);
    // Future expansion for UI panels
}
